# Galaxy Watch8 批发售价计算器 v6（原生修复版·底部按键调整）

**修复目标：** 之前的 APK 安装成功，但点击图标后没有反应。旧代码的 `MainActivity` 直接启动 Android `WebView`，而部分 Wear OS 设备不能提供 WebView 运行环境，可能在启动时崩溃。该 ZIP 改为 **完全原生 Android Java + Canvas 触控 UI**，不再用 WebView、HTML、JavaScript、浏览器、网络或手机伴侣程序。

## 保留的功能

- 黑色圆屏布局；顶部绿色售价、下面白色输入数字、四排大数字按键；数字过长时缩小字号避免被截断。
- 底部顺序：**AC｜=｜填入批发价｜退格（⌫）**（根据最新要求调整；第三键文字分为两行显示）。
- 税率：无税 / 21% / 25% / 28% / 自定义 0–999%；加价：30% / 40% / 50% / 80% / 60% / 自定义 0–999%。
- 计算优先级正常：乘除优先于加减。
- **最终售价 = 批发价 × (1 + 税率 ÷ 100) × (1 + 加价 ÷ 100)**。
- AC 同时归零白色输入、绿色售价、含税成本和加价金额；保留当前税率和加价设置。
- 记住上次选择的加价比例；无广告、无联网权限；无需 WebView。

`docs/previous_webview_ui_reference.html` 是旧界面的留档，**不会打包到新 APK**。

## GitHub 编译步骤（可生成真正的 APK）

1. 创建一个空 GitHub 仓库，或在原仓库中用本 ZIP 的所有文件更新仓库根目录，必须保留 `.github/workflows/build.yml`。
2. **重要：如果是原仓库，要删除旧的 `app/src/main/assets/index.html`**，以免使用者误以为此 APK 仍加载旧页面。
3. 进入 **Actions → Build Watch8 Calculator - Native No WebView → Run workflow**。
4. 等编译成功后，打开本次任务页面底部 **Artifacts → Watch8-Calculator-Native-v6-APK**。
5. 解压下载的 ZIP，获得 **app-debug.apk**；通过 Wear Installer 2 或 ADB 安装到 Galaxy Watch8。

## 旧版安装处理

新工程使用相同包名 `com.weixiaoyinjie.pricecalculator`，但 GitHub Actions 生成的 debug 签名可能与手表上旧包不同。如果覆盖安装提示签名冲突，请先在手表中卸载 **批发售价计算器**，再安装新 APK。卸载会清除旧版的设置。无须卸载其它程序。

## 自动核对

CI 编译后检查：
- `resources.arsc` 未压缩、4 字节对齐，避免 Android 11+ 安装错误 -124；
- `zipalign` 通过；APK v2/v3 签名通过；
- 确实具有 `MAIN`/`LAUNCHER` 可启动的 MainActivity；
- DEX 不再引用 `android.webkit.WebView`，且 APK 不包含旧 HTML。

**验证范围：** 已通过临时 Android API 形态测试桩对 Java 原生源码进行编译检查，并完成计算逻辑的单元烟雾测试（包括 21%×60%、28%×50%、AC 双清零、四则运算优先级）。由于当前环境没有 Android SDK/Gradle 下载通道，也无法连接你的真实 Watch8，此处**不附上未经实际编译验证的 APK**，请使用 GitHub Actions 编译产物。手表启动及触控仍以实机测试为准。

## 故障排查

若原生版仍闪退，可在已配对的 ADB 连接中执行：

```bash
adb shell am start -W -n com.weixiaoyinjie.pricecalculator/.MainActivity
adb logcat -d -t 300 | grep -E 'FATAL EXCEPTION|AndroidRuntime|pricecalculator'
```

将命令输出复制到对话里，可继续定位真实启动异常。
