package com.weixiaoyinjie.pricecalculator;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Galaxy Watch8 standalone calculator. Native Android Canvas, no WebView,
 * external browser, JavaScript engine, network or companion phone required.
 *
 * UI: settings, sale, input, 4 x 4 keypad, 4 bottom action buttons.
 * Formula: sale = wholesale * (1 + taxRate / 100) * (1 + profitRate / 100).
 */
public final class MainActivity extends Activity {
    private static final String PREFS = "watch8_calculator_settings";
    private static final int BG = Color.rgb(9, 12, 15);
    private static final int SURFACE = Color.rgb(23, 29, 33);
    private static final int BUTTON = Color.rgb(41, 45, 49);
    private static final int OPERATOR = Color.rgb(54, 59, 63);
    private static final int WHITE = Color.rgb(247, 247, 247);
    private static final int MUTED = Color.rgb(182, 184, 186);
    private static final int GREEN = Color.rgb(33, 215, 182);
    private static final int CYAN = Color.rgb(10, 173, 228);
    private static final int RED = Color.rgb(237, 63, 75);

    private float taxRate = 0f;
    private float profitRate = 60f;
    private boolean profitCustom = false;
    private boolean taxCustom = false;
    private double wholesale = 0d, taxed = 0d, markup = 0d, sale = 0d;
    private String expression = "";
    private String shown = "0";
    private int overlay = 0; // 0 calculator, 1 settings, 2 custom-percent keypad
    private boolean editingTax = true;
    private String rateDigits = "";
    private PriceView view;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        SharedPreferences preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        float stored = preferences.getFloat("profitRate", 60f);
        if (Float.isFinite(stored) && stored >= 0f && stored <= 999f) profitRate = stored;
        profitCustom = preferences.getBoolean("profitCustom", false);
        if (!profitCustom && !isPresetProfit(profitRate)) profitCustom = true;
        calculateSale();
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        view = new PriceView(this);
        setContentView(view);
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        if (overlay == 2) overlay = 1;
        else if (overlay == 1) overlay = 0;
        else { super.onBackPressed(); return; }
        view.invalidate();
    }

    private boolean isPresetProfit(float f) {
        return f == 30 || f == 40 || f == 50 || f == 60 || f == 80;
    }

    private void saveProfit() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putFloat("profitRate", profitRate)
                .putBoolean("profitCustom", profitCustom).apply();
    }

    private void calculateSale() {
        taxed = wholesale * (1.0 + taxRate / 100.0);
        markup = taxed * (profitRate / 100.0);
        sale = taxed + markup;
    }

    private static String fmt(double d) {
        if (!Double.isFinite(d)) return "错误";
        if (Math.abs(d) < 0.000000001) return "0";
        final int places = Math.abs(d) >= 1000 ? 2 : 4;
        DecimalFormat df = new DecimalFormat(places == 2 ? "#,##0.##" : "#,##0.####",
                DecimalFormatSymbols.getInstance(Locale.US));
        df.setRoundingMode(RoundingMode.HALF_UP);
        return df.format(d);
    }

    private static String rate(float r) {
        if (r == (int)r) return Integer.toString((int)r);
        return new BigDecimal(Float.toString(r)).stripTrailingZeros().toPlainString();
    }

    private void press(String action) {
        if ("SETTINGS".equals(action)) { overlay = 1; return; }
        if ("CLOSE".equals(action)) { overlay = 0; return; }
        if ("CUSTOM_TAX".equals(action) || "CUSTOM_PROFIT".equals(action)) {
            editingTax = "CUSTOM_TAX".equals(action);
            rateDigits = rate(editingTax ? taxRate : profitRate);
            overlay = 2;
            return;
        }
        if ("CANCEL_RATE".equals(action)) { overlay = 1; return; }
        if ("SAVE_RATE".equals(action)) {
            try {
                float r = Float.parseFloat(rateDigits.isEmpty() ? "0" : rateDigits);
                if (r >= 0 && r <= 999 && Float.isFinite(r)) {
                    if (editingTax) { taxRate = r; taxCustom = true; }
                    else { profitRate = r; profitCustom = true; saveProfit(); }
                    calculateSale();
                    overlay = 0;
                }
            } catch (NumberFormatException ignored) { }
            return;
        }
        if (action.startsWith("RATE_")) {
            String k = action.substring(5);
            if ("AC".equals(k)) rateDigits = "";
            else if ("BACK".equals(k)) {
                if (!rateDigits.isEmpty()) rateDigits = rateDigits.substring(0, rateDigits.length() - 1);
            } else if (rateDigits.length() < 3) {
                rateDigits = Integer.toString(Integer.parseInt((rateDigits.isEmpty() ? "" : rateDigits) + k));
            }
            return;
        }
        if (action.startsWith("TAX_")) {
            taxRate = Integer.parseInt(action.substring(4));
            taxCustom = false;
            calculateSale(); overlay = 0;
            return;
        }
        if (action.startsWith("PROFIT_")) {
            profitRate = Integer.parseInt(action.substring(7));
            profitCustom = false;
            saveProfit(); calculateSale(); overlay = 0;
            return;
        }
        if ("AC".equals(action)) {
            expression = ""; shown = "0"; wholesale = 0;
            calculateSale(); return;
        }
        if ("BACK".equals(action)) {
            if ("错误".equals(shown)) { shown = "0"; expression = ""; return; }
            if (!expression.isEmpty()) expression = expression.substring(0, expression.length() - 1);
            shown = expression.isEmpty() ? "0" : symbols(expression);
            return;
        }
        if ("EQUAL".equals(action) || "FILL".equals(action)) {
            try {
                if (expression.isEmpty() && "EQUAL".equals(action)) return;
                double value = expression.isEmpty() ? Double.parseDouble(shown.replace(",", ""))
                        : new CalculatorParser(expression).parse();
                if (!Double.isFinite(value)) throw new ArithmeticException("Invalid value");
                // 10 decimal places avoids accumulating floating-point noise.
                value = BigDecimal.valueOf(value).setScale(10, RoundingMode.HALF_UP).doubleValue();
                expression = BigDecimal.valueOf(value).stripTrailingZeros().toPlainString();
                shown = fmt(value);
                if ("FILL".equals(action)) { wholesale = value; calculateSale(); }
            } catch (Exception ex) {
                if ("EQUAL".equals(action)) { shown = "错误"; expression = ""; }
            }
            return;
        }
        if (action.startsWith("KEY_")) {
            String k = action.substring(4);
            if ("错误".equals(shown)) { expression = ""; shown = "0"; }
            if ("+".equals(k) || "-".equals(k) || "*".equals(k) || "/".equals(k)) {
                if (expression.isEmpty()) return;
                char last = expression.charAt(expression.length() - 1);
                if (last == '+' || last == '-' || last == '*' || last == '/')
                    expression = expression.substring(0, expression.length() - 1);
                expression += k;
            } else if (".".equals(k)) {
                int p = Math.max(Math.max(expression.lastIndexOf('+'), expression.lastIndexOf('-')),
                        Math.max(expression.lastIndexOf('*'), expression.lastIndexOf('/')));
                String last = expression.substring(p + 1);
                if (last.contains(".")) return;
                if (last.isEmpty()) expression += "0";
                expression += ".";
            } else {
                if (expression.equals("0")) expression = "";
                if (expression.length() < 36) expression += k;
            }
            shown = expression.isEmpty() ? "0" : symbols(expression);
        }
    }

    private static String symbols(String value) {
        return value.replace('*', '×').replace('/', '÷');
    }

    /** Safe arithmetic parser: + - * / with normal precedence, no eval/reflection. */
    private static final class CalculatorParser {
        final String input;
        int p;
        CalculatorParser(String s) { input = s; }
        double parse() {
            if (input.isEmpty()) throw new IllegalArgumentException();
            double result = addition();
            if (p != input.length()) throw new IllegalArgumentException("Trailing characters");
            return result;
        }
        double addition() {
            double v = product();
            while (p < input.length()) {
                char c = input.charAt(p);
                if (c != '+' && c != '-') break;
                p++;
                double rhs = product();
                v = c == '+' ? v + rhs : v - rhs;
            }
            return v;
        }
        double product() {
            double v = factor();
            while (p < input.length()) {
                char c = input.charAt(p);
                if (c != '*' && c != '/') break;
                p++;
                double rhs = factor();
                v = c == '*' ? v * rhs : v / rhs;
            }
            return v;
        }
        double factor() {
            if (p < input.length() && input.charAt(p) == '-') { p++; return -factor(); }
            if (p < input.length() && input.charAt(p) == '+') { p++; return factor(); }
            int start = p;
            while (p < input.length()) {
                char c = input.charAt(p);
                if ((c >= '0' && c <= '9') || c == '.') p++;
                else break;
            }
            if (start == p) throw new IllegalArgumentException("Expected number");
            return Double.parseDouble(input.substring(start, p));
        }
    }

    private static final class Hit {
        final RectF area;
        final String action;
        Hit(RectF r, String a) { area = r; action = a; }
    }

    private final class PriceView extends View {
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        final ArrayList<Hit> hits = new ArrayList<>();
        float w, h, unit;

        PriceView(Context context) { super(context); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            w = getWidth(); h = getHeight();
            unit = Math.min(w, h);
            c.drawColor(BG);
            hits.clear();
            drawCalculator(c);
            if (overlay == 1) drawSettings(c);
            else if (overlay == 2) drawRateInput(c);
        }

        private void rounded(Canvas c, RectF r, int color, float radius) {
            paint.setColor(color); paint.setStyle(Paint.Style.FILL);
            c.drawRoundRect(r, radius, radius, paint);
        }

        private RectF rect(float x1, float y1, float x2, float y2) {
            return new RectF(x1*w, y1*h, x2*w, y2*h);
        }

        private void text(Canvas c, String s, RectF r, float desiredSize,
                          int color, boolean bold, boolean rightAlign) {
            paint.setColor(color); paint.setStyle(Paint.Style.FILL);
            paint.setFakeBoldText(bold);
            paint.setTypeface(bold ? android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
                    : android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
            float size = desiredSize;
            paint.setTextSize(size);
            float available = r.width() - Math.min(12f, 0.025f*unit);
            while (paint.measureText(s) > available && size > 0.024f*unit) {
                size -= 0.6f;
                paint.setTextSize(size);
            }
            Paint.FontMetrics fm = paint.getFontMetrics();
            float y = r.centerY() - (fm.ascent + fm.descent) / 2f;
            float x = rightAlign ? r.right - Math.min(8f, unit*0.02f) - paint.measureText(s)
                    : r.centerX() - paint.measureText(s)/2f;
            c.drawText(s, x, y, paint);
            paint.setFakeBoldText(false);
        }

        private void cell(Canvas c, RectF r, String label, String action, int bg,
                          int fg, float fontSize, boolean bold) {
            rounded(c, r, bg, unit*0.026f);
            text(c, label, r, fontSize, fg, bold, false);
            if (action != null) hits.add(new Hit(new RectF(r), action));
        }

        private void drawCalculator(Canvas c) {
            cell(c, rect(.255f,.035f,.745f,.112f),
                    "⚙ 税" + rate(taxRate) + "% · 利" + rate(profitRate) + "%",
                    "SETTINGS", BUTTON, WHITE, .036f*unit, true);
            RectF output = rect(.21f,.135f,.79f,.227f);
            rounded(c, output, SURFACE, unit*.03f);
            text(c, fmt(sale), new RectF(output.left+unit*.025f, output.top,
                    output.right-unit*.015f, output.bottom), unit*.087f, GREEN, false, false);
            RectF input = rect(.065f,.245f,.935f,.326f);
            rounded(c, input, SURFACE, unit*.03f);
            text(c, shown, input, unit*.087f, WHITE, false, true);

            final String[][] labels = {
                    {"7","8","9","÷"},{"4","5","6","×"},
                    {"1","2","3","−"},{"0","00",".","+"}
            };
            final String[][] actions = {
                    {"7","8","9","/"},{"4","5","6","*"},
                    {"1","2","3","-"},{"0","00",".","+"}
            };
            final float[] widths = {.87f,.96f,.95f,.86f};
            float start = .344f*h;
            float end = .819f*h;
            float gap = Math.max(2, unit*.005f);
            float rowHeight = (end-start-3*gap)/4f;
            for (int row = 0; row < 4; row++) {
                float width = w*widths[row];
                float left = (w-width)/2;
                float y1 = start+row*(rowHeight+gap);
                float cw = (width-3*gap)/4f;
                for (int col = 0; col < 4; col++) {
                    RectF r = new RectF(left+col*(cw+gap), y1,
                            left+col*(cw+gap)+cw, y1+rowHeight);
                    cell(c,r,labels[row][col],"KEY_"+actions[row][col],
                            col == 3 ? OPERATOR : BUTTON, WHITE, unit*.098f, true);
                }
            }
            // Bottom button order: AC | Equals | Fill wholesale | Backspace.
            String[] lbl = {"AC","=","填入","⌫"};
            String[] act = {"AC","EQUAL","FILL","BACK"};
            int[] colors = {RED,Color.rgb(8,205,169),CYAN,BUTTON};
            float width = w*.71f, left = (w-width)/2f;
            float y1 = h*.829f, y2 = h*.936f;
            float cw = (width-3*gap)/4f;
            for(int i=0;i<4;i++){
                RectF r = new RectF(left+i*(cw+gap), y1, left+i*(cw+gap)+cw, y2);
                if (i == 2) {
                    rounded(c,r,colors[i],unit*.026f);
                    text(c,"填入",new RectF(r.left,r.top+.14f*r.height(),r.right,r.centerY()),
                            unit*.038f,WHITE,true,false);
                    text(c,"批发价",new RectF(r.left,r.centerY(),r.right,r.bottom-.10f*r.height()),
                            unit*.032f,WHITE,true,false);
                    hits.add(new Hit(new RectF(r),act[i]));
                } else {
                    cell(c,r,lbl[i],act[i],colors[i],WHITE,unit*.065f,true);
                }
            }
        }

        private void drawSettings(Canvas c) {
            paint.setColor(Color.argb(214,0,0,0));
            c.drawRect(0,0,w,h,paint);
            hits.clear();
            RectF panel = rect(.105f,.265f,.895f,.746f);
            rounded(c,panel,Color.rgb(24,28,31),unit*.05f);
            text(c,"税率与加价利润",rect(.165f,.277f,.755f,.340f),unit*.042f,WHITE,true,false);
            cell(c,rect(.765f,.283f,.85f,.338f),"×","CLOSE",OPERATOR,WHITE,unit*.05f,true);
            text(c,"含税成本 " + fmt(taxed),rect(.13f,.353f,.52f,.398f),unit*.028f,MUTED,false,false);
            text(c,"加价 " + fmt(markup),rect(.515f,.353f,.86f,.398f),unit*.028f,MUTED,false,false);
            text(c,"税率",rect(.145f,.398f,.34f,.441f),unit*.038f,WHITE,true,false);
            cell(c,rect(.645f,.398f,.862f,.443f),"自定义%","CUSTOM_TAX",
                    taxCustom ? CYAN:BUTTON,WHITE,unit*.028f,true);
            int[] taxes = {0,21,25,28};
            rowChoices(c,taxes,"TAX_",.445f,.513f,.12f,.76f,taxCustom ? -1 : (int)taxRate);
            text(c,"加价利润",rect(.145f,.528f,.44f,.572f),unit*.038f,WHITE,true,false);
            cell(c,rect(.645f,.525f,.862f,.572f),"自定义%","CUSTOM_PROFIT",
                    profitCustom ? CYAN:BUTTON,WHITE,unit*.028f,true);
            int[] profits = {30,40,50,80,60};
            rowChoices(c,profits,"PROFIT_",.583f,.663f,.12f,.76f,profitCustom ? -1 : (int)profitRate);
            text(c,"售价 = 原价 × (1 + 税%) × (1 + 加价%)",
                    rect(.12f,.672f,.88f,.725f),unit*.023f,MUTED,false,false);
        }

        private void rowChoices(Canvas c,int[] choices,String prefix,float y1,float y2,
                                float leftFrac,float totalWidthFrac,int activeValue){
            float left=leftFrac*w;
            float width=totalWidthFrac*w;
            float gap=Math.max(2,unit*.005f);
            float cw=(width-gap*(choices.length-1))/choices.length;
            for(int i=0;i<choices.length;i++){
                RectF r=new RectF(left+i*(cw+gap),y1*h,left+i*(cw+gap)+cw,y2*h);
                cell(c,r,choices[i]==0 ? "无税" : choices[i]+"%",
                        prefix+choices[i],choices[i]==activeValue ? CYAN:BUTTON,
                        WHITE,unit*.033f,true);
            }
        }

        private void drawRateInput(Canvas c) {
            paint.setColor(Color.argb(214,0,0,0));
            c.drawRect(0,0,w,h,paint);
            hits.clear();
            rounded(c,rect(.195f,.19f,.805f,.815f),Color.rgb(24,28,31),unit*.048f);
            text(c, editingTax?"自定义税率 %":"自定义加价 %",
                    rect(.24f,.205f,.76f,.265f),unit*.039f,WHITE,true,false);
            cell(c,rect(.705f,.205f,.78f,.27f),"×","CANCEL_RATE",OPERATOR,WHITE,unit*.045f,true);
            text(c,(rateDigits.isEmpty()?"0":rateDigits)+"%",
                    rect(.23f,.278f,.77f,.375f),unit*.096f,GREEN,true,false);
            String[] values={"7","8","9","4","5","6","1","2","3","清","0","⌫"};
            String[] actions={"7","8","9","4","5","6","1","2","3","AC","0","BACK"};
            float gap=Math.max(2,unit*.005f);
            float left=.24f*w;
            float cw=(.52f*w-2*gap)/3f;
            float start=.386f*h;
            float rh=.076f*h;
            for(int i=0;i<12;i++){
                int row=i/3,col=i%3;
                RectF r=new RectF(left+col*(cw+gap),start+row*(rh+gap),
                        left+col*(cw+gap)+cw,start+row*(rh+gap)+rh);
                cell(c,r,values[i],"RATE_"+actions[i],BUTTON,WHITE,unit*.05f,true);
            }
            cell(c,rect(.25f,.728f,.75f,.79f),"确定","SAVE_RATE",GREEN,Color.BLACK,unit*.044f,true);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() != MotionEvent.ACTION_DOWN) return true;
            float x=e.getX(),y=e.getY();
            for(int i=hits.size()-1;i>=0;i--) {
                Hit hit=hits.get(i);
                if(hit.area.contains(x,y)) {
                    press(hit.action); invalidate(); performClick(); return true;
                }
            }
            // Forgiving hit boxes for narrow gaps in the 4x4 calculator keypad.
            if (overlay == 0 && y >= h*.344f && y < h*.819f) {
                Hit nearest=null; double best=Double.POSITIVE_INFINITY;
                for(Hit hit : hits) {
                    if(!hit.action.startsWith("KEY_")) continue;
                    float dx=Math.max(Math.max(hit.area.left-x,x-hit.area.right),0f);
                    float dy=Math.max(Math.max(hit.area.top-y,y-hit.area.bottom),0f);
                    double d=dx*dx+dy*dy;
                    if(d<best){best=d;nearest=hit;}
                }
                if(nearest!=null && best < unit*unit*.004f) {
                    press(nearest.action); invalidate(); performClick(); return true;
                }
            }
            return true;
        }
        @Override public boolean performClick() { super.performClick(); return true; }
    }
}
