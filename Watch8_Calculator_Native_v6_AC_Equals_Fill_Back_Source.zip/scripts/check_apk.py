#!/usr/bin/env python3
"""Verify stand-alone Wear OS APK resources and absence of WebView dependence."""
import struct
import sys
import zipfile

if len(sys.argv) != 2:
    sys.exit('Usage: python3 scripts/check_apk.py path/to/app.apk')

path = sys.argv[1]
with zipfile.ZipFile(path) as apk:
    names = apk.namelist()
    if 'resources.arsc' not in names:
        sys.exit('FAIL: resources.arsc missing')
    resource = apk.getinfo('resources.arsc')
    with open(path, 'rb') as handle:
        handle.seek(resource.header_offset)
        header = handle.read(30)
        if header[:4] != b'PK\x03\x04':
            sys.exit('FAIL: invalid local ZIP header')
        name_size, extra_size = struct.unpack_from('<HH', header, 26)
        offset = resource.header_offset + 30 + name_size + extra_size
    if resource.compress_type != zipfile.ZIP_STORED:
        sys.exit('FAIL: resources.arsc compressed: Android 11+ installation risk')
    if offset % 4:
        sys.exit('FAIL: resources.arsc not 4-byte-aligned')
    if 'assets/index.html' in names:
        sys.exit('FAIL: obsolete WebView index.html still packaged')
    dex = [name for name in names if name.endswith('.dex') and name.startswith('classes')]
    if not dex:
        sys.exit('FAIL: app contains no DEX bytecode')
    for name in dex:
        raw = apk.read(name)
        if b'Landroid/webkit/WebView;' in raw:
            sys.exit('FAIL: native app still depends on android.webkit.WebView')
    print(f'PASS: Android 11+ resources, 4-byte aligned ({offset})')
    print('PASS: classes*.dex found and no WebView use')
    print('PASS: WebView assets not packaged')
